# 查看当前挂载的数据集目录, 该目录下的变更重启环境后会自动还原
# View dataset directory. 
# This directory will be recovered automatically after resetting environment. 
!ls /home/aistudio/data

# 查看工作区文件, 该目录下的变更将会持久保存. 请及时清理不必要的文件, 避免加载过慢.
# View personal work directory. 
# All changes under this directory will be kept even after reset. 
# Please clean unnecessary files in time to speed up environment loading. 
!ls /home/aistudio/work

# 如果需要进行持久化安装, 需要使用持久化路径, 如下方代码示例:
# If a persistence installation is required, 
# you need to use the persistence path as the following: 
!mkdir /home/aistudio/external-libraries
!pip install beautifulsoup4 -t /home/aistudio/external-libraries

# 同时添加如下代码, 这样每次环境(kernel)启动的时候只要运行下方代码即可: 
# Also add the following code, 
# so that every time the environment (kernel) starts, 
# just run the following code: 
import sys 
sys.path.append('/home/aistudio/external-libraries')

!gzip -dfq /home/aistudio/data/data65/t10k-labels-idx1-ubyte.gz
!gzip -dfq /home/aistudio/data/data65/train-labels-idx1-ubyte.gz
!gzip -dfq /home/aistudio/data/data65/t10k-images-idx3-ubyte.gz
!gzip -dfq /home/aistudio/data/data65/train-images-idx3-ubyte.gz
import os
import struct
import numpy as np
import matplotlib.pyplot as plt
import paddle
from paddle.nn import Linear
import paddle.nn as nn
import paddle.nn.functional as F
from paddle.vision.models import ResNet
from paddle.vision.models.resnet import BottleneckBlock, BasicBlock
%matplotlib inline

paddle.device.set_device("gpu:0")

def data_load():
    # train
    # 读取标签数据集
    with open('./data/data65/train-labels-idx1-ubyte', 'rb') as lbpath:
        labels_magic, labels_num = struct.unpack('>II', lbpath.read(8))
        train_labels = np.fromfile(lbpath, dtype=np.uint8)

    # 读取图片数据集
    with open('./data/data65/train-images-idx3-ubyte', 'rb') as imgpath:
        images_magic, images_num, rows, cols = struct.unpack('>IIII', imgpath.read(16))
        train_images = np.fromfile(imgpath, dtype=np.uint8).reshape(images_num, rows * cols) 
    # test
    with open('./data/data65/t10k-labels-idx1-ubyte','rb') as test_label_path:
        labels_magic, labels_num = struct.unpack('>II', test_label_path.read(8))
        test_labels=np.fromfile(test_label_path,dtype=np.uint8)

    with open('./data/data65/t10k-images-idx3-ubyte','rb') as test_img_path:
        images_magic, images_num, rows, cols = struct.unpack('>IIII', test_img_path.read(16))
        test_images = np.fromfile(test_img_path, dtype=np.uint8).reshape(images_num, rows * cols) 
    # 打印数据信息
    print('labels_magic is {} \n'.format(labels_magic),
        'labels_num is {} \n'.format(labels_num),
        'labels is {} \n'.format(train_labels))

    print('images_magic is {} \n'.format(images_magic),
        'images_num is {} \n'.format(images_num),
        'rows is {} \n'.format(rows),
        'cols is {} \n'.format(cols),
        'images is {} \n'.format(train_images))
    train_images=np.array(train_images)
    return train_images,train_labels,test_images,test_labels

# 测试取出一张图片和对应标签
train_images,train_labels,test_images,test_labels=data_load()
print(train_images.shape,train_labels.shape,test_images.shape,test_labels.shape)
choose_num = 0 # 指定一个编号，你可以修改这里
label = train_labels[choose_num]
image = train_images[choose_num].reshape(28,28)
plt.imshow(image)
plt.title('the label is : {}'.format(label))
plt.show()

# 图像归一化函数，将数据范围为[0, 255]的图像归一化到[-1, 1]
def norm_img(img):
    # # 验证传入数据格式是否正确，img的shape为[batch_size, 28* 28]
    # assert len(img.shape) == 3
    # batch_size, img_h, img_w = img.shape[0], img.shape[1], img.shape[2]
    # 归一化图像数据
    img = img/127.5 - 1
    # 将图像形式reshape为[batch_size, 784]
    return img

# 图像的打乱操作
def shuffle_img(images,labels):
    if type(images)==type([]):
        images=np.array(images)
    number=images.shape[0]
    index_list=list(range(number))
    np.random.shuffle(index_list)
    # print(index_list)
    images_,labels_=[],[]
    for index in index_list:
        images_.append(images[index])
        labels_.append(labels[index])
    return np.array(images_),np.array(labels_)
images=[[1,1],[2,2],[3,3]]
labels=[1,2,3]
images,labels=shuffle_img(images,labels)
print(images,labels)

# 图像分为若干个batch
def batch_img(images,labels,batch_size=16):
    if type(images)==type([]):
        images=np.array(images)
    max_number=images.shape[0]
    max_batch_num=int(max_number/batch_size)+1
    images_,labels_=[],[]
    for k in range(max_batch_num):
        if (k+1)*batch_size<max_number:
            images_.append(images[k*batch_size:(k+1)*batch_size])
            labels_.append(labels[k*batch_size:(k+1)*batch_size])
        else:
            images_.append(images[k*batch_size:])
            labels_.append(labels[k*batch_size:])
    images_,labels_=np.array(images_),np.array(labels_)
    return images_,labels_

def dataloader(train_images,train_labels,batch_size=16,shuffle=True,normalization=True):
    if normalization==True:
        train_images=norm_img(train_images)
        print('Hi')
    if shuffle==True:
        train_images,train_labels=shuffle_img(train_images,train_labels)
    train_images,train_labels=batch_img(train_images,train_labels,batch_size=batch_size)
    return train_images,train_labels

def train(model,train_images,train_labels):
    model.train()
    batch_size=128
    lr=0.1
    epoch_num=10
    train_images_,train_labels_=dataloader(train_images,train_labels,batch_size)
    opt = paddle.optimizer.SGD(learning_rate=lr, parameters=model.parameters())
    for epoch in range(epoch_num):
        for batch_id,images in enumerate(train_images_):
            images=images.astype(np.float32)
            labels = train_labels_[batch_id]
            labels=labels.astype(np.int64)
            # print('5:',images.shape)
            # print(images.shape)
            images=np.reshape(images,(images.shape[0],1,28,28))
            images=paddle.to_tensor(images)
            labels=paddle.to_tensor(labels)
            
            #前向计算的过程
            out = model(images)
            # print(f'epoch:{epoch},batch_id:{batch_id}')
            # predicts = paddle.argmax(out, 1)
            # print('####:',predicts)
            # print('111:',labels)
            # 计算损失
            loss = F.cross_entropy(out, labels).astype(np.float32)
            # print('***',loss)
            avg_loss = paddle.mean(loss)
            
            #每训练了100批次的数据，打印下当前Loss的情况
            if batch_id % 100 == 0:
                print("epoch_id: {}, batch_id: {}, loss is: {}".format(epoch, batch_id, avg_loss.numpy()))
            
            #后向传播，更新参数的过程
            opt.clear_grad()
            avg_loss.backward()
            opt.step()
            

def test(model,test_images,test_labels):
    model.eval()
    test_images=np.reshape(test_images,(test_images.shape[0],1,28,28))
    test_images=paddle.to_tensor(test_images).astype(np.float32)
    test_labels=paddle.to_tensor(test_labels).astype(np.int64)
    out=model(test_images)
    predicts = paddle.argmax(out, 1)
    print(predicts)
    print(test_labels)
    accuracy=sum(predicts.numpy()==test_labels.numpy())/np.float32(predicts.shape[0])
    print(f'accuracy:{accuracy}')

class LeNet_5(paddle.nn.Layer):
    def __init__(self, number_classes=10):
        super(LeNet_5, self).__init__()
        self.conv = nn.Sequential(
            nn.Conv2D(1, 6, 5, 1, 2),  # 28*28->28*28
            nn.ReLU(),
            nn.MaxPool2D(kernel_size=2, stride=2),  # 28*28->14*14
            nn.Conv2D(6, 16, 5),  # 14*14->10*10
            nn.ReLU(),
            nn.MaxPool2D(2, 2),  # 10*10->5*5
            nn.Conv2D(16, 120, 5),  # 5*5->1*1
            nn.ReLU(),
        )
        self.classifier = nn.Sequential(
            nn.Linear(120, 84),
            nn.ReLU(),
            nn.Linear(84, number_classes)
        )

    def forward(self, x):
        x = self.conv(x)
        x = paddle.fluid.layers.flatten(x=x, axis=1)
        x = self.classifier(x)
        return x
LeNet_5()

train_images,train_labels,_,_=data_load()
model=LeNet_5()
train(model,train_images,train_labels)

_,_,test_images,test_labels=data_load()
test(model,test_images,test_labels)
paddle.save(model.state_dict(), 'mnist_in_LeNet5.pdparams')

import os
import numpy as np
import matplotlib.pyplot as plt
import paddle
from paddle.nn import Linear
import paddle.nn as nn
import paddle.nn.functional as F
from paddle.vision.models import ResNet
from paddle.vision.models.resnet import BottleneckBlock, BasicBlock
from paddle.vision.transforms import Compose, Normalize
%matplotlib inline

paddle.device.set_device("gpu:0")

# 加载数据集
transform = Compose([Normalize(mean=[127.5],
                               std=[127.5],
                               data_format='CHW')])
train_dataset = paddle.vision.datasets.MNIST(mode='train', transform=transform)
test_dataset = paddle.vision.datasets.MNIST(mode='test', transform=transform)

# 模型封装
model=resnet50 = ResNet(BasicBlock,50,10)
model.conv1=nn.Conv2D(1,64,kernel_size=7,stride=2,padding=3)
model = paddle.Model(model)

# 为模型训练做准备，设置优化器，损失函数和精度计算方式
model.prepare(optimizer=paddle.optimizer.Adam(learning_rate=0.001,parameters=model.parameters()),
              loss=paddle.nn.CrossEntropyLoss(),
              metrics=paddle.metric.Accuracy())
              
# 启动模型训练，指定训练数据集，设置训练轮次，设置每次数据集计算的批次大小，设置日志格式
model.fit(train_dataset,
          epochs=2,
          batch_size=64,
          verbose=1)
model.save('mnist_in_Resnet.pdparams')        
# 用 evaluate 在测试集上对模型进行验证
eval_result = model.evaluate(test_dataset, verbose=1)

# 用 predict 在测试集上对模型进行测试
test_result = model.predict(test_dataset)

